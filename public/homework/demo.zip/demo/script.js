



// let img = document.createElement("img");
// img.src = "insta.png";
// img.id="img_id";

// let body = document.querySelector("body");

// body.appendChild(img);

let button = document.querySelector("#btn_add");
button.addEventListener('click', say);

function say() {
//    let image = document.querySelector("h1");
//    image.innerHTML = " HIIIIIII ";  
//    image.classList.remove("hello");
  

let img = document.createElement("button");
img.innerHTML = "new button created";
img.classList.add("n");

 let div = document.querySelector("#btns");
div.appendChild(img);
}











let button2 = document.querySelector("#btn_remove");
button2.addEventListener('click', removeBtn);

function removeBtn() {

let img = document.querySelector(".n");

let div = document.querySelector("#btns");
div.removeChild(img);
}


