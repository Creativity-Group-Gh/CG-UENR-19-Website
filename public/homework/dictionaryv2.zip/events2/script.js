// abate	to lessen to subside
// abeyance	suspended action
// abjure	promise or swear to give up
// abrogate	repeal or annul by authority
// abstruse	difficult to comprehend obscure
// acarpous	effete no longer fertile worn out
// accretion	the growing of separate things into one
// agog	eager/excited
// alloy	to debase by mixing with something inferior
// amortize	end (a debt) by setting aside money

let words = ['amortized', 'alloy','agog','acarpous'];

let dictionary = {
        'amortized' : 'end (a debt) by setting aside money',
        alloy : 'to debase by mixing with something inferior',
        agog :'eager/excited',
        'acarpous': 'effete no longer fertile worn out'
    };


let body = document.querySelector('section');

for(let i=0; i<words.length; i++ ){
   
    //creates the div
    let div = document.createElement('div');
   
    //collect name from list
    let name = words[i];

    //insert name in the div
    div.innerHTML = name;

    //append to parent
    body.appendChild(div);

    //add event listener to div
    div.addEventListener("mouseover", (event)=>{

        let new_div = event.target;
        console.log(new_div);
        // let word = new_div.textContent;
        let word = new_div.innerHTML;
        console.log(word);

        let meaning = dictionary[word];


        let h1 = document.querySelector('h1');
       h1.textContent = meaning;

    }  );

}

console.log(words);




